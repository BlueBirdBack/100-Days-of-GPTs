---
cssClass: reference
---

This page lists CSS variables the workspace.

## CSS variables

| Variable                             | Description                        |
| ------------------------------------ | ---------------------------------- |
| `--workspace-background-translucent` | Background for translucent windows |
