---
cssClass: reference
---

This page lists CSS variables for horizontal rules.

## CSS variables

| Variable         | Description                      |
| ---------------- | -------------------------------- |
| `--hr-color`     | Horizontal rule border color     |
| `--hr-thickness` | Horizontal rule border thickness |
