---
cssClass: reference
---

This page lists CSS variables for footnotes.

## CSS variables

| Variable          | Description        |
| ----------------- | ------------------ |
| `--footnote-size` | Footnote font size |
