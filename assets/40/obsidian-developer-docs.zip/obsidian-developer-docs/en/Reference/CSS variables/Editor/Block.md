---
cssClass: reference
---

This page lists CSS variables for rendered blocks in Live Preview.

## CSS variables

| Variable                     | Description                                            |
| ---------------------------- | ------------------------------------------------------ |
| `--embed-block-shadow-hover` | Hover shadow for rendered embed blocks in Live Preview |
