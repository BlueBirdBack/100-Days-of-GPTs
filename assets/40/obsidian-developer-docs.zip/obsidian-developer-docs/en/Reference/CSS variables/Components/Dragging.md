---
cssClasses: reference
---

Obsidian displays dragging affordances while the user drag files or tabs.

## CSS variables

| Variable                  | Description                 |
| ------------------------- | --------------------------- |
| `--drag-ghost-background` | Drag ghost background color |
| `--drag-ghost-text-color` | Drag ghost text color       |
