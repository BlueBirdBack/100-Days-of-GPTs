---
cssClass: reference
---

This page lists CSS variables for buttons. For button colors, refer to [[Colors#Interactive colors|Interactive colors]].

## CSS variables

| Variable          | Description   |
| ----------------- | ------------- |
| `--button-radius` | Button radius |
