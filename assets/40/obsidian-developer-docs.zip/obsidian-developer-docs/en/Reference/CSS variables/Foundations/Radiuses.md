---
cssClass: reference
---

Radiuses define the rounded corners for UI elements.

| Variable      | Default value |
| ------------- | ------------- |
| `--radius-s`  | `4px`         |
| `--radius-m`  | `8px`         |
| `--radius-l`  | `12px`        |
| `--radius-xl` | `16px`        |
