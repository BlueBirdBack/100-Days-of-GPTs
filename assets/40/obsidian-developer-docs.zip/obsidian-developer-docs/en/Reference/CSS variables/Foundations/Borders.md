---
cssClasses: reference
---

Border thicknesses applied to UI elements. 

| Variable         | Default value |
| ---------------- | ------------- |
| `--border-width` | `1px`         |
