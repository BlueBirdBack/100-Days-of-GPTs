---
cssClass: reference
---

This page lists CSS variables used by the [File explorer](https://help.obsidian.md/Plugins/File+explorer) plugin.

## CSS variables

| Variable                   | Description |
| -------------------------- | ----------- |
| `--vault-name-font-size`   | Font size   |
| `--vault-name-font-weight` | Font weight |
| `--vault-name-color`       | Text color  |
