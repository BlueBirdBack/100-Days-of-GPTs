import * as en from './en.json';
import * as zh_cn from './zh-cn.json';

export const LANGUAGES = {
  en,
  zh_cn
};
