﻿// pch.cpp : source file for generating the MinSize.pch precompiled header.
// See the ApplyMinSizePCH target in AutoHotkey.vcxproj for details.

#include "stdafx.h"

// reference any additional headers you need in STDAFX.H
// and not in this file
