﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AutoHotkey.rc
//
#define VS_VERSION_INFO                 1
#define IDS_PROJNAME                    100
#define IDR_WMDMLOGGER                  101
#define IDI_MAIN                        159
#define IDI_FILETYPE                    160
#define IDS_LOG_SEV_INFO                201
#define IDC_INPUTEDIT                   201
#define IDS_LOG_SEV_WARN                202
#define IDR_MENU1                       202
#define IDS_LOG_SEV_ERROR               203
#define IDS_LOG_DATETIME                204
#define IDC_INPUTPROMPT                 204
#define IDS_LOG_SRCNAME                 205
#define IDD_INPUTBOX                    205
#define IDI_SUSPEND                     206
#define IDI_PAUSE                       207
#define IDI_PAUSE_SUSPEND               208
#define IDR_MENU_MAIN                   211
#define IDR_ACCELERATOR1                212
#define IDS_DEF_LOGFILE                 301
#define IDS_DEF_MAXSIZE                 302
#define IDS_DEF_SHRINKTOSIZE            303
#define IDS_DEF_LOGENABLED              304
#define IDS_MUTEX_TIMEOUT               401
#define ID_FILE_RELOADSCRIPT            65400
#define ID_FILE_EDITSCRIPT              65401
#define ID_FILE_WINDOWSPY               65402
#define ID_FILE_PAUSE                   65403
#define ID_FILE_SUSPEND                 65404
#define ID_FILE_EXIT                    65405
#define ID_VIEW_LINES                   65406
#define ID_VIEW_VARIABLES               65407
#define ID_VIEW_HOTKEYS                 65408
#define ID_VIEW_KEYHISTORY              65409
#define ID_VIEW_REFRESH                 65410
#define ID_HELP_USERMANUAL              65411
#define ID_HELP_WEBSITE                 65412
#define IDD_ERRORBOX                    500
#define IDC_ERR_EDIT                    501

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        236
#define _APS_NEXT_COMMAND_VALUE         65414
#define _APS_NEXT_CONTROL_VALUE         206
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif



#ifdef _WIN64
#define AHK_BIT "64-bit"
#else
#define AHK_BIT "32-bit"
#endif

#define AHK_DESCRIPTION "AutoHotkey " AHK_BIT
