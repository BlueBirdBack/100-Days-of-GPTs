Sample code for the [Executing arbitrary strings][section] section of the MV3 migration documentation.

[section]: https://developer.chrome.com/docs/extensions/mv3/intro/mv3-migration/#executing-arbitrary-strings
