document.getElementById('title').textContent = chrome.i18n.getMessage('title');
document.getElementById('content').textContent =
  chrome.i18n.getMessage('content');
