module.exports = {
    singleQuote: true,
    jsxSingleQuote: true,
    semi: false,
    trailingComma: 'es5',
    tabWidth: 4,
    useTabs: false,
    quoteProps: 'consistent',
    bracketSpacing: true,
    printWidth: 120,
}
