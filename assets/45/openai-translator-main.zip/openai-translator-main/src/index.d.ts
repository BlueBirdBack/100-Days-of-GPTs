/// <reference types="@samrum/vite-plugin-web-extension/client" />

declare module '*.png'
declare module '*.gif'
declare module '*.jpg'
declare module '*.jpeg'
declare module '*.css'
declare module 'iso-639-3-to-1'
declare module '*.css?inline'
declare module '*.svg?react'
declare module '*.svg'
