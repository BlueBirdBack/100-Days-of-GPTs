declare module 'i18next' {}
